#include <zephyr/geom/box.h>
#include <zephyr/math/random.h>

namespace zephyr::geom {

Box Box::NaN() {
    return {Vector3d{NAN, NAN, NAN},
            Vector3d{NAN, NAN, NAN}};
}

Box Box::Zero() {
    return {Vector3d::Zero(), Vector3d::Zero()};
}

Box Box::Empty(int dim) {
    const double max = +std::numeric_limits<double>::infinity();
    const double min = -std::numeric_limits<double>::infinity();

    if (dim < 3) {
        return {Vector3d{max, max, 0.0}, Vector3d{min, min, 0.0}};
    } else {
        return {Vector3d{max, max, max}, Vector3d{min, min, min}};
    }
}

Box Box::Infinite(int dim){
    const double max = +std::numeric_limits<double>::infinity();
    const double min = -std::numeric_limits<double>::infinity();

    if (dim < 3) {
        return {Vector3d{min, min, 0.0}, Vector3d{max, max, 0.0}};
    } else {
        return {Vector3d{min, min, min}, Vector3d{max, max, max}};
    }
}

Vector3d Box::center() const {
    return 0.5 * (vmin + vmax);
}

Vector3d Box::size() const {
    return vmax - vmin;
}

bool Box::is_2D() const {
    return std::abs(vmax.z() - vmin.z()) <  1.0e-6 * std::abs(vmax.x() - vmin.x());
}

bool Box::is_3D() const {
    return std::abs(vmax.z() - vmin.z()) >= 1.0e-6 * std::abs(vmax.x() - vmin.x());
}

double Box::diameter() const {
    return (vmax - vmin).norm();
}

double Box::area() const {
    return (vmax[0] - vmin[0]) * (vmax[1] - vmin[1]);
}

double Box::volume() const {
    return (vmax[0] - vmin[0]) * (vmax[1] - vmin[1]) * (vmax[2] - vmin[2]);
}

bool Box::inside(const Vector3d& p) const {
    return vmin.x() <= p.x() && p.x() <= vmax.x() &&
           vmin.y() <= p.y() && p.y() <= vmax.y() &&
           vmin.z() <= p.z() && p.z() <= vmax.z();
}

Vector3d Box::shove_in(const Vector3d& p) const {
    return {
            std::max(vmin.x(), std::min(p.x(), vmax.x())),
            std::max(vmin.y(), std::min(p.y(), vmax.y())),
            std::max(vmin.z(), std::min(p.z(), vmax.y()))
    };
}

void Box::capture(const Vector3d& p) {
    if (p.x() < vmin.x()) {
        vmin.x() = p.x();
    } else if (p.x() > vmax.x()) {
        vmax.x() = p.x();
    }

    if (p.y() < vmin.y()) {
        vmin.y() = p.y();
    } else if (p.y() > vmax.y()) {
        vmax.y() = p.y();
    }

    if (p.z() < vmin.z()) {
        vmin.z() = p.z();
    } else if (p.z() > vmax.z()) {
        vmax.z() = p.z();
    }
}

std::vector<double> Box::outline_x() const {
    return {vmin.x(), vmax.x(), vmax.x(), vmin.x(), vmin.x()};
}

std::vector<double> Box::outline_y() const {
    return {vmin.y(), vmin.y(), vmax.y(), vmax.y(), vmin.y()};
}

void Box::extend(double margin) {
    extend(margin, margin, margin);
}

void Box::extend(double margin_x, double margin_y, double margin_z) {
    Vector3d L = size();
    vmin.x() -= margin_x * L.x();
    vmin.y() -= margin_y * L.y();
    vmin.z() -= margin_z * L.z();

    vmax.x() += margin_x * L.x();
    vmax.y() += margin_y * L.y();
    vmax.z() += margin_z * L.z();
}

std::ostream& operator<<(std::ostream& os, const Box& box) {
    os << "[" << box.vmax.x() << ", " << box.vmax.x() << "] × [" <<
       box.vmax.x() << ", " << box.vmax.x() << "]";
    if (box.is_3D()) {
        os << " × [" << box.vmax.z() << ", " << box.vmax.z() << "]";
    }
    return os;
}

math::Random2D Box::random2D(int seed) const {
    return math::Random2D(vmin, vmax, seed);
}

math::QuasiRandom2D Box::quasiRandom2D() const {
    return math::QuasiRandom2D(vmin, size());
}

} // namespace zephyr::geom