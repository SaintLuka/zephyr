#include <fstream>
#include <iomanip>
#include <set>

#include <zephyr/mesh/euler/eu_mesh.h>
#include <zephyr/mesh/euler/eu_prim.h>

#include <zephyr/geom/generator/rectangle.h>
#include <zephyr/geom/generator/cuboid.h>
#include <zephyr/geom/primitives/polygon.h>
#include <zephyr/geom/grid.h>

#include <zephyr/mesh/amr/apply.h>
#include <zephyr/mesh/amr/balancing.h>

#include <zephyr/utils/json.h>
#include <zephyr/io/pvd_file.h>

namespace zephyr::mesh {

using namespace geom;
using namespace utils;
using generator::Rectangle;
using generator::Cuboid;
using utils::Stopwatch;
using namespace io;

namespace {

AmrCells make_locals(geom::Grid&& grid) {
    // Опции генерации сетки
    constexpr Grid::BuildOptions opts{
        .faces=Grid::BuildOptions::FaceOption::per_cell,
        .build_face_local_indices=true,
        .build_twin_face=false,
        .build_edges=false,
        .build_node_cells=false,
        .build_node_faces=false,
        .compute_face_geometry=true,
        .compute_cell_geometry=true
    };

    grid.finalize(opts);

    if (true) {
        std::string report;
        grid.validate_finalized_full(&report);
        std::cout << report << std::endl;
    }

    return AmrCells(grid);
}

} // anonymous namespace

void EuMesh::sync_params_() {
#ifdef ZEPHYR_MPI
    if (!mpi::single()) {
        int dim = m_locals.dim();
        int adapt = m_locals.adaptive();
        int axial = m_locals.axial();

        // Соберем базовые характеристики сетки с master-процесса
        mpi::broadcast(0, dim);
        mpi::broadcast(0, adapt);
        mpi::broadcast(0, axial);

        if (!mpi::master()) {
            m_locals.set_dimension(dim);
            m_locals.set_adaptive(adapt);
            m_locals.set_axial(axial);
        }
    }

    // установить dim/adapt/axial
    m_tourists.init_types(m_locals);
#endif
}

void EuMesh::build_(Generator& gen) {
    if (mpi::master()) {
        Grid grid = gen.make();
        m_locals = make_locals(std::move(grid));
    }
    sync_params_();

    // Иногда генератор позволяет восстановить структуру сетки
    if (mpi::single()) {
        // Структурированность не работает для распределенных расчетов
        if (gen.can_cast<Rectangle>()) {
            Rectangle& rect = gen.cast<Rectangle>();
            if (rect.structured()) {
                m_structured = true;
                m_nx = rect.nx();
                m_ny = rect.ny();
                m_nz = 1;
            }
        } else if (gen.can_cast<Cuboid>()) {
            Cuboid& cuboid = gen.cast<Cuboid>();
            m_structured = true;
            m_nx = cuboid.nx();
            m_ny = cuboid.ny();
            m_nz = cuboid.nz();
        }
    }
}

EuMesh::EuMesh(Grid&& grid) {
    if (mpi::master()) {
        m_locals = make_locals(std::move(grid));
    }
    sync_params_();
}

EuMesh::EuMesh(Generator& gen) {
    build_(gen);
}

EuMesh::EuMesh(int dim, bool adaptive, bool axial)
    : m_locals(dim, adaptive, axial) {
}

EuMesh::EuMesh(const Json& config) {
    // Создать сетку на master-процессе
    auto gen = Generator::create(config);
    build_(*gen);

    m_max_level = 0;
    if (config["max_level"]) {
        m_max_level = std::max(0, config["max_level"].as<int>());
        if (m_max_level > 15) {
            std::cerr << "Max level set up to " << m_max_level << ", decreased to 15\n";
            m_max_level = 15;
        }
    }
    if (config["adaptive"]) {
        // Есть ключевое слово adaptive, выставлено на false
        if (!config["adaptive"].as<bool>()) {
            m_max_level = 0;
        }
    }

    // Если есть декомпозиция, то использовать
    if (!mpi::single()) {
        Box domain = bbox();

        if (config["decomp"]) {
            // Там все свойства декомпозиции автоматически ставятся
            m_decomp = Decomposition::create(domain, config["decomp"]);

            //set_decomposition("XY");
            set_decomposition(m_decomp, true);
        }
        else {
            // Определяем размерность сетки
            int dim = m_locals.empty() ? 0 : m_locals.dim();
            dim = mpi::max(dim);

            assert((dim == 2 || dim == 3) && "Strange dimension, EuMesh constructed by json");

            // По умолчанию что-то такое
            set_decomposition(dim < 3 ? "XY" : "XYZ");
        }
    }
}

void EuMesh::init_amr() {
    // Эта функция нифига не используется же?
    m_max_level = 0;

    if (m_locals.empty()) {
        return;
    }

    int rank = mpi::rank();
    int size = mpi::size();

    auto cells_nums = mpi::all_gather(m_locals.size());
    std::vector<int> offset(size, 0);
    for (int r = 0; r < size - 1; ++r) {
        offset[r + 1] = offset[r] + cells_nums[r];
    }

    for (int ic = 0; ic < m_locals.size(); ++ic) {
        m_locals.b_idx[ic] = offset[rank] + ic;
        m_locals.z_idx[ic] = 0;
        m_locals.level[ic] = 0;
        m_locals.flag [ic] = 0;
    }
}

bool EuMesh::adaptive() const {
    return m_max_level > 0;
}

int EuMesh::max_level() const {
    return m_max_level;
}

void EuMesh::set_max_level(int max_level) {
    if (!m_locals.adaptive()) {
        m_max_level = 0;
    } else {
        m_max_level = std::max(0, std::min(max_level, 15));
    }
}

void EuMesh::set_distributor(const std::string& name) {
    if (name == "empty") {
        m_distributor = Distributor::empty();
    } else {
        m_distributor = Distributor::simple();
    }
}

void EuMesh::set_distributor(Distributor distr) {
    m_distributor = std::move(distr);
}

void EuMesh::balance_flags() {
#if SCRUTINY
    static bool first_time = true;
    if (first_time) {
        if (check_base() < 0) {
            throw std::runtime_error("Check base failed");
        }
        first_time = false;
    }
#endif
    if (mpi::single()) {
        amr::balance_flags(m_locals, m_max_level);
    }
#ifdef ZEPHYR_MPI
    else {
        amr::balance_flags(m_locals, m_max_level, m_tourists);
    }
#endif
}

void EuMesh::apply_flags() {
#if SCRUTINY
    static size_t pvd_counter = 0;

    static PvdFile locals_before("app_bef_locals", "debug");
    static PvdFile aliens_before("app_bef_aliens", "debug");
    static PvdFile border_before("app_bef_border", "debug");
    static PvdFile locals_after("app_aft_locals", "debug");
    static PvdFile aliens_after("app_aft_aliens", "debug");
    static PvdFile border_after("app_aft_border", "debug");

    if (pvd_counter == 0) {
        Variables vars = {"rank", "index", "next", "level", "flag", "faces2D"};
        locals_before.variables = vars;
        aliens_before.variables = vars;
        border_before.variables = vars;
        locals_after.variables = vars;
        aliens_after.variables = vars;
        border_after.variables = vars;
    }
    //locals_before.save(m_locals, pvd_counter);
    //aliens_before.save(m_aliens, pvd_counter);
    //border_before.save(m_tourists.m_border, pvd_counter);
    mpi::barrier();
#endif

    if (mpi::single()) {
        amr::apply(m_locals, m_distributor);
    }
#ifdef ZEPHYR_MPI
    else {
        amr::apply(m_locals, m_distributor, m_tourists);
    }
#endif

#if SCRUTINY
    //locals_after.save(m_locals, pvd_counter);
    //aliens_after.save(m_aliens, pvd_counter);
    //border_after.save(m_tourists.m_border, pvd_counter);
    mpi::barrier();
    ++pvd_counter;

    mpi::for_each([&]() {
        if (check_refined() < 0) {
            std::cout << "Check refined for rank " << mpi::rank() << "\n";
            throw std::runtime_error("Check refined failed");
        }
    });
#endif
}

void EuMesh::make_shuba(int count) {
    count = std::max(0, std::min(count, 50));

    for (int i = 1; i <= count; i++) {
#ifdef ZEPHYR_MPI
        if (!mpi::single()) {
            m_tourists.sync<MpiTag::FLAG>(m_locals);
        }
#endif
        for_each([&](EuCell& cell) {
            if (cell.flag() > 0) return;
            for (auto face: cell.faces()) {
                if (face.neib_flag() == i) {
                    cell.set_flag(i + 1);
                    return;
                }
            }
        });
    }
}

void EuMesh::refine() {
    if (!adaptive()) { return; }

    m_nodes.clear();

    static Stopwatch balance;
    static Stopwatch apply;
    static Stopwatch full;

    // Для однопроцессорной версии при пустой сетке сразу выход
    if (mpi::single() && m_locals.empty()) {
        throw std::runtime_error("EuMesh::refine() error: Empty mesh");
    }

    full.resume();

    balance.resume();
    balance_flags();
    balance.stop();

    apply.resume();
    apply_flags();
    apply.stop();

    full.stop();

#if CHECK_PERFORMANCE
    static size_t counter = 0;
    if (counter % amr::check_frequency == 0) {
        mpi::cout << "  Balance flags: " << std::setw(14) << balance.milliseconds_mpi() << " ms\n";
        mpi::cout << "  Apply flags:   " << std::setw(14) << apply.milliseconds_mpi() << " ms\n";
        mpi::cout << "Refine elapsed:  " << std::setw(14) << full.milliseconds_mpi() << " ms\n";
    }
    ++counter;
#endif
}

void EuMesh::refine_full(int level) {
    if (level < 0 || level > m_max_level) {
        level = m_max_level;
    }
    if (level == 0) {
        return;
    }

    for (int i = 0; i < level; ++i) {
        for_each([level](EuCell &cell) {
            cell.set_flag(cell.level() < level ? 1 : 0);
        });
        refine();
    }
}

void EuMesh::check_reference(bool fix) {
    Box box = bbox();
    double xmin = box.vmin.x();
    double xmax = box.vmax.x();
    double ymin = box.vmin.y();
    double ymax = box.vmax.y();

    if (m_locals.empty()) return;

    int level = m_locals.level[0];

    int nx = m_nx * std::pow(2, level);
    int ny = m_ny * std::pow(2, level);

    double hx = (xmax - xmin) / nx;
    double hy = (ymax - ymin) / ny;
    double volume = hx * hy;


    std::cout << std::setprecision(14);

    std::cout << "BBox: " << box << "\n";

    std::cout << "Structured: " << nx << " x " << ny << " cells\n";

    auto get_center = [=](int i, int j) -> Vector3d {
        return {xmin + (i + 0.5) * hx, ymin + (j + 0.5) * hy, 0.0};
    };
    auto lface_center = [=](int i, int j) -> Vector3d {
        return {xmin + (i + 0.0) * hx, ymin + (j + 0.5) * hy, 0.0};
    };
    auto rface_center = [=](int i, int j) -> Vector3d {
        return {xmin + (i + 1.0) * hx, ymin + (j + 0.5) * hy, 0.0};
    };
    auto bface_center = [=](int i, int j) -> Vector3d {
        return {xmin + (i + 0.5) * hx, ymin + (j + 0.0) * hy, 0.0};
    };
    auto tface_center = [=](int i, int j) -> Vector3d {
        return {xmin + (i + 0.5) * hx, ymin + (j + 1.0) * hy, 0.0};
    };
    auto get_vertex = [=](double i, double j) -> Vector3d {
        return {xmin + i * hx, ymin + j * hy, 0.0};
    };

    double cell_volume_error = 0.0;
    double cell_center_error = 0.0;
    double face_area_error = 0.0;
    double face_normal_error = 0.0;
    double face_center_error = 0.0;
    double vertices_error = 0.0;

    for (auto& cell: m_locals) {
        int i = std::round((cell.x() - 0.5 * hx - xmin) / hx);
        int j = std::round((cell.y() - 0.5 * hy - ymin) / hy);

        // Погрешности данных ячейки
        cell_volume_error = std::max(cell_volume_error, std::abs(cell.volume() - volume));
        cell_center_error = std::max(cell_center_error, (cell.center() - get_center(i, j)).norm());

        // Погрешности для граней
        face_area_error = std::max(
                {
                        face_area_error,
                        std::abs(cell.face(Side2D::L).area() - hy),
                        std::abs(cell.face(Side2D::R).area() - hy),
                        std::abs(cell.face(Side2D::B).area() - hx),
                        std::abs(cell.face(Side2D::T).area() - hx),
                });

        face_normal_error = std::max(
                {
                        face_normal_error,
                        (cell.face(Side2D::L).normal() + Vector3d::UnitX()).norm(),
                        (cell.face(Side2D::R).normal() - Vector3d::UnitX()).norm(),
                        (cell.face(Side2D::B).normal() + Vector3d::UnitY()).norm(),
                        (cell.face(Side2D::T).normal() - Vector3d::UnitY()).norm()
                });

        face_center_error = std::max(
                {
                        face_center_error,
                        (cell.face(Side2D::L).center() - lface_center(i, j)).norm(),
                        (cell.face(Side2D::R).center() - rface_center(i, j)).norm(),
                        (cell.face(Side2D::B).center() - bface_center(i, j)).norm(),
                        (cell.face(Side2D::T).center() - tface_center(i, j)).norm()
                });

        // Погрешности для вершин
        SqQuad quad = cell.mapping<2>();
        vertices_error = std::max(
                {
                        vertices_error,
                        (quad.vs<-1, -1>() - get_vertex(i + 0.0, j + 0.0)).norm(),
                        (quad.vs< 0, -1>() - get_vertex(i + 0.5, j + 0.0)).norm(),
                        (quad.vs<+1, -1>() - get_vertex(i + 1.0, j + 0.0)).norm(),
                        (quad.vs<-1,  0>() - get_vertex(i + 0.0, j + 0.5)).norm(),
                        (quad.vs< 0,  0>() - get_vertex(i + 0.5, j + 0.5)).norm(),
                        (quad.vs<+1,  0>() - get_vertex(i + 1.0, j + 0.5)).norm(),
                        (quad.vs<-1, +1>() - get_vertex(i + 0.0, j + 1.0)).norm(),
                        (quad.vs< 0, +1>() - get_vertex(i + 0.5, j + 1.0)).norm(),
                        (quad.vs<+1, +1>() - get_vertex(i + 1.0, j + 1.0)).norm(),

                });
    }

    // Линейный размер
    double H = std::max(hx, hy);

    cell_volume_error /= volume;
    cell_center_error /= H;

    face_area_error   /= H;
    face_center_error /= H;
    vertices_error    /= H;

    std::cout << "Errors\n";
    std::cout << "  Cell volume:  " << cell_volume_error << "\n";
    std::cout << "  Cell center:  " << cell_volume_error << "\n";
    std::cout << "  Face areas:   " << face_area_error << "\n";
    std::cout << "  Face centers: " << face_center_error << "\n";
    std::cout << "  Face normals: " << face_normal_error << "\n";
    std::cout << "  Vertices:     " << vertices_error << "\n";

    // Исправить сетку, если необходимо
    if (fix) {
        for (auto& cell: m_locals) {
            index_t ic = cell.index();
            
            int i = std::round((cell.x() - 0.5 * hx - xmin) / hx);
            int j = std::round((cell.y() - 0.5 * hy - ymin) / hy);

            m_locals.volume[ic] = volume;
            m_locals.center[ic] = get_center(i, j);

            index_t iface = m_locals.face_begin[ic];

            m_locals.faces.area[iface + Side2D::L] = hy;
            m_locals.faces.area[iface + Side2D::R] = hy;
            m_locals.faces.area[iface + Side2D::B] = hx;
            m_locals.faces.area[iface + Side2D::T] = hx;

            m_locals.faces.normal[iface + Side2D::L] = -Vector3d::UnitX();
            m_locals.faces.normal[iface + Side2D::R] =  Vector3d::UnitX();
            m_locals.faces.normal[iface + Side2D::B] = -Vector3d::UnitY();
            m_locals.faces.normal[iface + Side2D::T] =  Vector3d::UnitY();

            m_locals.faces.center[iface + Side2D::L] = lface_center(i, j);
            m_locals.faces.center[iface + Side2D::R] = rface_center(i, j);
            m_locals.faces.center[iface + Side2D::B] = bface_center(i, j);
            m_locals.faces.center[iface + Side2D::T] = tface_center(i, j);

            SqQuad& quad = m_locals.mapping<2>(ic);
            quad.vs<-1, -1>() = get_vertex(i + 0.0, j + 0.0);
            quad.vs< 0, -1>() = get_vertex(i + 0.5, j + 0.0);
            quad.vs<+1, -1>() = get_vertex(i + 1.0, j + 0.0);
            quad.vs<-1,  0>() = get_vertex(i + 0.0, j + 0.5);
            quad.vs< 0,  0>() = get_vertex(i + 0.5, j + 0.5);
            quad.vs<+1,  0>() = get_vertex(i + 1.0, j + 0.5);
            quad.vs<-1, +1>() = get_vertex(i + 0.0, j + 1.0);
            quad.vs< 0, +1>() = get_vertex(i + 0.5, j + 1.0);
            quad.vs<+1, +1>() = get_vertex(i + 1.0, j + 1.0);
        }
    }
}

int EuMesh::check_base() const {
    if (m_locals.empty()) {
        if (mpi::single()) {
            std::cout << "\tEmpty storage\n";
            return -1;
        } else {
            return 0;
        }
    }

    auto dim = m_locals.dim();

    if (dim != 2 && dim != 3) {
        std::cout << "\tDimension is not 2 or 3\n";
        return -1;
    }

    // Только для адаптивных сеток
    if (!m_locals.adaptive()) {
        std::cout << "\tOnly adaptive meshes\n";
        return -1;
    }

    int res = 0;
    for (index_t ic = 0; ic < m_locals.size(); ++ic) {
        if (m_locals.index[ic] < 0 || m_locals.index[ic] != ic) {
            std::cout << "\tWrong cell index\n";
            return -1;
        }

        if (m_locals.rank[ic] < 0 || m_locals.rank[ic] != mpi::rank()) {
            std::cout << "\tWrong cell rank\n";
            return -1;
        }

        // Число граней
        for (int i = 0; i < FpC(dim); ++i) {
            if (m_locals.faces.is_undefined(m_locals.face_begin[ic] + i)) {
                std::cout << "\tCell has no one of main faces\n";
                m_locals.print_info(ic);
                return -1;
            }
        }

        if (m_locals.face_count(ic) > FpC(dim)) {
            std::cout << "\tCell has too much faces (" << m_locals.face_count(ic) << ")\n";
            m_locals.print_info(ic);
            return -1;
        }

        // Проверим число вершин
        int n_nodes = m_locals.node_count(ic);
        int n_max_nodes = m_locals.max_node_count(ic);
        if ((dim == 2 && n_nodes == n_max_nodes && n_max_nodes != 9) ||
            (dim == 3 && n_nodes == n_max_nodes && n_max_nodes != 27)) {
            std::cout << "\tCell has wrong node count " << n_nodes << " " << n_max_nodes << "\n";
            m_locals.print_info(ic);
            return -1;
        }

        // Проверим число граней
        int n_faces = m_locals.face_count(ic);
        int n_max_faces = m_locals.max_face_count(ic);
        if ((dim == 2 && (n_faces > n_max_faces || n_max_faces != 8)) ||
            (dim == 3 && (n_faces > n_max_faces || n_max_faces != 24))) {
            std::cout << "\tCell has wrong face count " << n_faces << " " << n_max_faces << "\n";
            m_locals.print_info(ic);
            return -1;
        }

        // Правильное задание геометрии
        res = m_locals.check_geometry(ic);
        if (res < 0) return res;

        // Грани правильно ориентированы
        res = m_locals.check_base_face_orientation(ic);
        if (res < 0) return res;

        // Порядок основных вершин
        res = m_locals.check_base_vertices_order(ic);
        if (res < 0) return res;

        // Проверка смежности
#ifdef ZEPHYR_MPI
        res = m_locals.check_connectivity(ic, m_tourists.aliens());
#else
        AmrCells aliens = m_locals.same();
        res = m_locals.check_connectivity(ic, aliens);
#endif
        if (res < 0) return res;
    }

    return 0;
}

int EuMesh::check_refined() const {
    if (m_locals.empty()) {
        if (mpi::single()) {
            std::cout << "\tEmpty storage\n";
            return -1;
        } else {
            return 0;
        }
    }

    auto dim = m_locals.dim();

    if (dim != 2 && dim != 3) {
        std::cout << "\tDimension is not 2 or 3\n";
        return -1;
    }

    int res = 0;
    for (index_t ic = 0; ic < m_locals.size(); ++ic) {
        if (m_locals.is_undefined(ic)) {
            std::cout << "\tUndefined cell\n";
            return -1;
        }

        if (m_locals.index[ic] < 0 || m_locals.index[ic] != ic) {
            std::cout << "\tWrong cell index\n";
            return -1;
        }

        if (m_locals.rank[ic] < 0 || m_locals.rank[ic] != mpi::rank()) {
            std::cout << "\tWrong cell rank\n";
            return -1;
        }

        // Число граней
        for (int i = 0; i < FpC(dim); ++i) {
            if (m_locals.faces.is_undefined(m_locals.face_begin[ic] + i)) {
                std::cout << "\tCell has no one of main faces\n";
                m_locals.print_info(ic);
                return -1;
            }
        }

        // Вершины дублируются
        for (int i = m_locals.node_begin[ic]; i < m_locals.node_begin[ic + 1]; ++i) {
            for (int j = i + 1; j < m_locals.node_begin[ic + 1]; ++j) {
                double dist = (m_locals.verts[i] - m_locals.verts[j]).norm();
                if (dist < 1.0e-5 * m_locals.linear_size(ic)) {
                    std::cout << "\tIdentical vertices\n";
                    m_locals.print_info(ic);
                    return -1;
                }
            }
        }

        // Правильное задание геометрии
        res = m_locals.check_geometry(ic);
        if (res < 0) return res;

        // Грани правльно ориентированы
        res = m_locals.check_base_face_orientation(ic);
        if (res < 0) return res;

        // Порядок основных вершин
        res = m_locals.check_base_vertices_order(ic);
        if (res < 0) return res;

        // Проверка сложных граней
        res = m_locals.check_complex_faces(ic);
        if (res < 0) return res;

        // Проверка смежности
#ifdef ZEPHYR_MPI
        res = m_locals.check_connectivity(ic, m_tourists.aliens());
#else
        AmrCells aliens = m_locals.same();
        res = m_locals.check_connectivity(ic, aliens);
#endif
        if (res < 0) return res;
    }

    return 0;
}

Box EuMesh::bbox() const {
    Box box1 = Box::Empty(3);
    for (auto& v: m_locals.verts) {
        box1.capture(v);
    }

    Box box2(box1);

#ifdef ZEPHYR_MPI
    if (!mpi::single()) {
        // Покомпонентный минимум/максимум
        MPI_Allreduce(box1.vmin.data(), box2.vmin.data(), 3, MPI_DOUBLE, MPI_MIN, mpi::comm());
        MPI_Allreduce(box1.vmax.data(), box2.vmax.data(), 3, MPI_DOUBLE, MPI_MAX, mpi::comm());
    }
#endif

    return box2;
}

void EuMesh::push_back(const geom::Line& line) {
    geom::Polygon poly = {line[0], line[1], line[1], line[0]};
    m_locals.push_back(poly);
}

void EuMesh::push_back(const geom::Polygon& poly) {
    m_locals.push_back(poly);
}

void EuMesh::push_back(const geom::Polyhedron& poly) {
    m_locals.push_back(poly);
}

void EuMesh::add_marker(const geom::Vector3d& pos, double size) {
    if (dim() < 3) {
        double c1 = 0.5 * size;
        double c2 = 0.5 * size * std::sqrt(3.0);
        Vector3d a = {0.0, -size, 1.0};
        Vector3d b = {+c2, c1, 1.0};
        Vector3d c = {-c2, c1, 1.0};
        Polygon poly = {pos + a, pos + b, pos + c};
        push_back(poly);
    }
    else {
        throw std::runtime_error("3D markers not supported");
    }
}

EuCell_Iter EuMesh::begin() {
    return {&m_locals, 0,
        mpi_cond(&m_tourists.aliens(), nullptr) };
}

EuCell_Iter EuMesh::end() {
    return {&m_locals, m_locals.size(),
        mpi_cond(&m_tourists.aliens(), nullptr) };
}

EuCell EuMesh::operator[](index_t idx) {
    return {&m_locals, idx,
        mpi_cond(&m_tourists.aliens(), nullptr) };
}

EuCell EuMesh::operator()(int i, int j) {
    i = (i + m_nx) % m_nx;
    j = (j + m_ny) % m_ny;
    return operator[](m_ny * i + j);
}

EuCell EuMesh::operator()(int i, int j, int k) {
    i = (i + m_nx) % m_nx;
    j = (j + m_ny) % m_ny;
    k = (k + m_nz) % m_nz;
    return operator[](m_nz * (m_ny * i + j) + k);
}

inline int nodes_estimation(int n_cells, int dim) {
    z_assert(dim == 2 || dim == 3, "bad dimension");
    if (dim < 3) {
        int nx = int(std::ceil(std::sqrt(n_cells))) + 2;
        return nx * nx;
    } else {
        int nx = int(std::ceil(std::cbrt(n_cells))) + 2;
        return nx * nx * nx;
    }
}

// Владелец узла (любая ячейка, которая содержит узел)
// Основной владелец: ячейка с минимальным индексом.
struct NodeOwner {
    index_t ic; // Индекс ячейки
    index_t iv; // Индекс вершины

    // Считаем различие только по индексу ячейки
    bool operator<(const NodeOwner& other) const { return ic < other.ic; }
};

// Множество ячеек, которые владеют некоторым узлом
struct NodeOwners {
    // Добавить владельца
    void insert(index_t ic, int iv) {
        owners.insert(NodeOwner{ic, iv});
    }

    // Имеется владелец с индексом ic?
    bool contain(index_t ic) const {
        return owners.count(NodeOwner{ic, -1}) > 0;
    }

    auto begin() const { return owners.begin(); }

    auto end() const { return owners.end(); }

    std::set<NodeOwner> owners;
};

NodeOwners find_owners(const AmrCells& cells, index_t ic_start, int iv_start) {
    // Интересующая нас вершина
    Vector3d p = cells.verts[iv_start];
    double eps = 1.0e-10 * cells.linear_size(ic_start);

    // Моделирует стек с ячейками в работе
    std::vector<NodeOwner> in_work;

    in_work.emplace_back(NodeOwner{ic_start, iv_start});

    NodeOwners owners;
    while (!in_work.empty()) {
        // Извлекли из стека последнюю ячейку
        auto[ic, iv] = in_work.back();
        in_work.pop_back();

        // Добавили нового владельца
        owners.insert(ic, iv);

        // Проходим по граням, ищем грани, которые содержат искомую вершину.
        // Сосед через такую грань также содержит искомую вершину.
        for (auto iface: cells.faces_range(ic)) {
            if (cells.faces.is_undefined(iface) ||
                cells.faces.is_boundary(iface) ||
                cells.faces.boundary[iface] == Boundary::PERIODIC ||
                cells.faces.adjacent.is_alien(iface)) {
                continue;
            }

            // Проверить, что грань содержит искомую вершину
            bool contain = false;
            for (int j = 0; j < AmrFaces::max_vertices; ++j) {
                int loc_iv = cells.faces.vertices[iface][j];
                if (loc_iv < 0) break;
                if (cells.node_begin[ic] + loc_iv == iv) {
                    contain = true;
                    break;
                }
            }

            if (!contain) continue;

            // Грань содержит целевую вершину

            // Индекс соседа через грань
            index_t ic_n = cells.faces.adjacent.index[iface];
            z_assert(ic_n < cells.size(), "Find owners: Out of range");

            // Сосед уже есть в массиве
            if (owners.contain(ic_n)) continue;

            // Ищем интересующую вершину среди вершин соседа
            index_t iv_n = -1;
            for (auto iv2: cells.nodes_range(ic_n)) {
                if ((cells.verts[iv2] - p).norm() < eps) {
                    // Проверка на -13??
                    iv_n = iv2;
                    break;
                }
            }

            z_assert(iv_n >= 0, "AmrFaces::setup_for: Impossible error #1");

            // Соседняя ячейка нам подходит, помещаем в стек
            in_work.emplace_back(NodeOwner{ic_n, iv_n});
        }
    }

    return owners;
}

bool AmrNodes::empty() const {
    return nodes.empty();
}

void AmrNodes::clear() {
    nodes.clear();
    unique_verts.clear();
}

void AmrNodes::setup_for(const AmrCells& cells) {
    // Стираем существующий массив узлов
    clear();

    if (cells.empty()) return;

    // Выставляем все индексы на -1
    nodes.resize(cells.n_nodes(), -1);

    // Помечаем актуальные узлы, которые есть на каких-либо гранях, индексом -13.
    threads::parallel_for(
        index_t{0}, cells.n_cells(),
        [this, &cells](index_t ic) {
            for (auto iface: cells.faces_range(ic)) {
                if (cells.faces.is_undefined(iface)) continue;

                for (int j = 0; j < AmrFaces::max_vertices; ++j) {
                    int loc_iv =  cells.faces.vertices[iface][j];
                    if (loc_iv < 0) break;
                    nodes[cells.node_begin[ic] + loc_iv] = -13;
                }
            }
        });


    // TODO: Заменить set, vector на быстрые версии на стеке
    // TODO: Есть только наметки, как это сделать параллельно

    /// Последовательная версия работает за один проход по ячейкам
    unique_verts.reserve(nodes_estimation(cells.size(), cells.dim()));

    int counter = 0;
    for (index_t ic = 0; ic < cells.n_cells(); ++ic) {
        for (index_t iv: cells.nodes_range(ic)) {
            // Нас интересуют актуальные (отмеченные) узлы, которые
            // ещё не получили уникальный индекс.
            if (nodes[iv] != -13) continue;

            // Добавляем узел в массив
            unique_verts.push_back(cells.verts[iv]);

            // Ищем все ячейки, которые содержат узел
            auto owners = find_owners(cells, ic, iv);

            // Отмечаем индекс узла у каждого владельца
            for (auto [ic2, iv2]: owners) {
                nodes[iv2] = counter;
            }
            ++counter;
        }
    }
}

void EuMesh::collect_nodes() {
    if (has_nodes()) return;
    m_nodes.setup_for(m_locals);
}

} // namespace zephyr::mesh
