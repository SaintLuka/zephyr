// Не устанавливается при установке zephyr, детали алгоритмов и комментарии
// к функциям предназначены для разработчиков.
#pragma once

#include <zephyr/mesh/amr/common.h>

namespace zephyr::mesh::amr {

/// @brief Содержит статистику о числе ячеек с флагами -1, 0 и 1 в некотором
/// диапазоне ячеек. В том числе и для одной ячейки.
struct PartStatistics {
    index_t n_coarse = 0; ///< Число ячеек в диапазоне для огрубления
    index_t n_retain = 0; ///< Число ячеек в диапазоне, которые сохраняют уровень
    index_t n_refine = 0; ///< Число ячеек в диапазоне для разбиения

    /// @brief Конструктор по умолчанию с нулями.
    PartStatistics() = default;

    /// @brief Для суммирования статистики в тредах
    PartStatistics& operator+=(const PartStatistics& other) {
        n_coarse += other.n_coarse;
        n_retain += other.n_retain;
        n_refine += other.n_refine;
        return *this;
    }
};

inline PartStatistics cell_statistics(int flag) {
    if (!flag) {
        return {.n_retain=1};
    }
    if (flag > 0) {
        return {.n_refine=1};
    }
    return {.n_coarse=1};
}

/// @brief Содержит статистику о числе ячеек с флагами -1, 0 и 1, число новых
/// дочерних и родительских ячеек и другие параметры
struct Statistics {
    index_t n_cells    = 0;  ///< Исходное количество в AmrStorage (перед адаптацией)
    index_t n_coarse   = 0;  ///< Число ячеек для огрубления (кратно числу дочерних ячеек CpC)
    index_t n_retain   = 0;  ///< Число ячеек для сохранения
    index_t n_refine   = 0;  ///< Число ячеек для разбиения
    index_t n_parents  = 0;  ///< Число новых родительских ячеек (n_coarse/CpC)
    index_t n_children = 0;  ///< Число новых детей (CpC * n_refine)

    /// @brief Размер расширенного хранилища, после добавления новых ячеек,
    /// полученных разбиением или огрублением старых, всегда больше или равно
    /// исходному размеру хранилища n_cells
    index_t n_cells_large = 0;

    /// @brief Итоговый размер хранилища, после удаления старых (не листовых)
    /// ячеек из хранилища
    index_t n_cells_short = 0;

    Statistics() = default;

    /// @brief Конструктор, однопоточный сбор статистики
    /// @details В многопоточном режиме данные получаются после объединения 
    /// статистики с разных потоков
    Statistics(const std::vector<int>& flags, int dim) {
        n_cells = flags.size();

        scrutiny_check(n_cells >= 0, "Empty AmrStorage statistics");

        PartStatistics ps = threads::sum(
            flags.cbegin(), flags.cend(),
            PartStatistics{}, cell_statistics);

        n_coarse = ps.n_coarse;
        n_retain = ps.n_retain;
        n_refine = ps.n_refine;

        // Пересчитаем зависимые величины
        scrutiny_check(n_coarse % CpC(dim) == 0, "Refiner::apply() error #2")
        scrutiny_check(n_retain + n_refine + n_coarse == n_cells, "Refiner::apply() error #1");

        n_parents =  n_coarse / CpC(dim);
        n_children = n_refine * CpC(dim);

        n_cells_large = n_cells + n_parents + n_children;
        n_cells_short = n_retain + n_children + n_parents;
    }

    /// @brief Выводит статистику
    void print() const {
        mpi::for_each([this] {
            if (!mpi::single()) {
                std::cout << "rank " << mpi::rank() << "\n";
            }
            std::cout << "Apply statistic:\n";
            std::cout << "\tn_cells:       " << n_cells << "\n";
            std::cout << "\tn_retain:      " << n_retain << "\n";
            std::cout << "\tn_coarse:      " << n_coarse << "\n";
            std::cout << "\tn_parents:     " << n_parents << "\n";
            std::cout << "\tn_refine:      " << n_refine << "\n";
            std::cout << "\tn_children:    " << n_children << "\n";
            std::cout << "\tn_cells_large: " << n_cells_large << "\n";
            std::cout << "\tn_cells_short: " << n_cells_short << "\n";
        });
    }
};

} // namespace zephyr::mesh::amr