// @brief В geom/curves определено несколько классов параметрических кривых
// и сплайнов, протестируем их здесь.
#include <zephyr/geom/curves/linear_spline.h>
#include <zephyr/geom/curves/cubic_spline.h>
#include <zephyr/geom/curves/lagrange.h>

#include <zephyr/utils/numpy.h>
#include <zephyr/utils/pyplot.h>

using namespace zephyr;
using namespace zephyr::geom;
using namespace zephyr::geom::curves;

utils::line_options node_style = {
    .linestyle="none", .color="black", .marker="o", .markersize=4
};

// Обычные интерполянты: y(x)
void ordinary_interpolants() {
    // Оригинальная функция
    double L = 5.0;
    auto func = [L](double x) -> double {
        return std::sin(2.0 * M_PI * x / L);
    };
    auto x_all = np::linspace(0.0, L, 1000);
    auto y_all = np::zeros_like(x_all);
    for (size_t i = 0; i < x_all.size(); ++i) {
        y_all[i] = func(x_all[i]);
    }

    // Узлы сплайна
    std::vector<double> xs = {0.0, 0.12, 0.3, 0.46, 0.6, 0.82, 0.94, 1.0};
    std::vector<double> ys(xs.size());
    for (size_t i = 0; i < xs.size(); ++i) {
        xs[i] *= L;
        ys[i] = func(xs[i]);
    }
    ys.back() = ys.front();

    LinearSpline line1(xs, ys, SplineBound::Free, SplineBound::Crop);
    LinearSpline line2(xs, ys, SplineBound::Free, SplineBound::Periodic);
    Lagrange     poly1(xs, ys, SplineBound::Free, SplineBound::Crop);
    Lagrange     poly2(xs, ys, SplineBound::Free, SplineBound::Periodic);
    CubicSpline cubic1(xs, ys, SplineBound::Crop, SplineBound::Free);
    CubicSpline cubic2(xs, ys, SplineBound::Crop, SplineBound::Periodic);

    utils::line_options orig_style = {
        .linestyle="solid", .linewidth=0.5, .color="black", .label="Original",
    };

    utils::pyplot plt;
    plt.figure({.figsize={9.0, 5.0}, .dpi=150});

    // Crop/Free на границах
    plt.subplot(2, 1, 1);
    plt.grid(true);

    plt.plot(line1.xs(2000, -0.1 * L, 1.1 * L), line1.ys(2000, -0.1 * L, 1.1 * L),
            {.linestyle="dashed", .color="blue", .label="Linear [Free, Crop]"});

    plt.plot(cubic1.xs(200, -0.1 * L, 1.1 * L), cubic1.ys(200, -0.1 * L, 1.1 * L),
            {.linestyle="solid", .color="orange", .label="Cubic [Free, Crop]"});

    plt.plot(poly1.xs(200, -0.1 * L, 1.1 * L), poly1.ys(200, -0.1 * L, 1.1 * L),
            {.linestyle="dashed", .color="red", .label="L poly [Free, Crop]"});

    plt.plot(x_all, y_all, orig_style);

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Периодические граничные условия
    plt.subplot(2, 1, 2);
    plt.grid(true);

    plt.plot(cubic2.xs(200, -L, 1.5 * L), cubic2.ys(200, -L, 1.5 * L),
            {.linestyle="solid", .color="orange", .label="Cubic  [Periodic]",});

    plt.plot(line2.xs(2000, -L, 1.5 * L), line2.ys(2000, -L, 1.5 * L),
            {.linestyle="dashed", .color="blue", .label="Linear [Periodic]"});

    plt.plot(poly2.xs(200, -L, 1.5 * L), poly2.ys(200, - L, 1.5 * L),
            {.linestyle="dashed", .color="red", .label="L poly [Periodic]",});

    plt.plot(x_all, y_all, orig_style);

    plt.plot(xs, ys, node_style);
    plt.legend();

    plt.suptitle("Обычные сплайны: $y(x)$");
    plt.tight_layout();
    plt.show();
}

// Параметрические интерполянты: x(t), y(t)
void parametric_interpolants() {
    // Узлы сплайна
    std::vector<double> xs = {0.0, 4.0, 10.0, 7.0, 8.0, 1.0};
    std::vector<double> ys = {1.0, 5.0,  6.0, 3.0, 0.0, 0.0};

    PLinearSpline line1(xs, ys, SplineBound::Free, SplineBound::Crop);
    PLinearSpline line2(xs, ys, SplineBound::Free, SplineBound::Periodic);
    PLagrange     poly1(xs, ys, SplineBound::Free, SplineBound::Crop);
    PLagrange     poly2(xs, ys, SplineBound::Free, SplineBound::Periodic);
    PCubicSpline cubic1(xs, ys, SplineBound::Crop, SplineBound::Free);
    PCubicSpline cubic2(xs, ys, SplineBound::Crop, SplineBound::Periodic);

    utils::pyplot plt;
    
    plt.figure({.figsize={9.0, 3.8}, .dpi=150});

    // Crop/Free на границах
    plt.subplot(1, 2, 1);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(line1.xs(2000, -0.1, 1.1), line1.ys(2000, -0.1, 1.1),
            {.linestyle="dashed", .color="blue",.label="Linear [Free, Crop]"});

    plt.plot(cubic1.xs(200, -0.1, 1.1), cubic1.ys(200, -0.1, 1.1),
            {.linestyle="solid", .color="orange", .label="Cubic  [Crop, Free]"});

    plt.plot(poly1.xs(200, -0.1, 1.1), poly1.ys(200, -0.1, 1.1),
            {.linestyle="solid", .color="red", .label="L poly [Free, Crop]"});

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Периодические граничные условия
    plt.subplot(1, 2, 2);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(cubic2.xs(200, 0.0, 1.0), cubic2.ys(200, 0.0, 1.0),
            {.linestyle="solid", .color="orange", .label="Cubic  [Periodic]"});

    plt.plot(line2.xs(2000, 0.0, 1.0), line2.ys(2000, 0.0, 1.0),
            {.linestyle="dashed", .color="blue", .label="Linear [Periodic]"});

    plt.plot(poly2.xs(2000, 0.0, 1.0), poly2.ys(2000, 0.0, 1.0),
            {.linestyle="solid", .color="red", .label="L poly [Periodic]"});

    plt.plot(xs, ys, node_style);
    plt.legend();

    plt.suptitle("Параметрические иннтерполянты: $x(t)$, $y(t)$");
    plt.tight_layout();
    plt.show();
}

// Параметризация кубических сплайнов
void cubic_parametrization() {
    // Узлы сплайна
    std::vector<double> xs = {0.0, 4.0, 10.0, 7.0, 8.0, 1.0};
    std::vector<double> ys = {1.0, 5.0, 6.0, 3.0, 0.0, 0.0};

    PCubicSpline cubic1(xs, ys, SplineBound::Crop, SplineBound::Periodic, Parametrization::Uniform);
    PCubicSpline cubic2(xs, ys, SplineBound::Crop, SplineBound::Periodic, Parametrization::Chord);
    PCubicSpline cubic3(xs, ys, SplineBound::Crop, SplineBound::Periodic, Parametrization::Chebyshev);

    // Число тестовых точек
    int n = 50;
    int N = 200;

    utils::pyplot plt;
    plt.figure({.figsize={9.0, 7}, .dpi=150});

    // Все виды параметризации
    plt.subplot(2, 2, 1);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(cubic1.xs(N), cubic1.ys(N), {.color="blue", .label="Uniform"});
    plt.plot(cubic2.xs(N), cubic2.ys(N), {.color="green", .label="Chord Length"});
    plt.plot(cubic3.xs(N), cubic3.ys(N), {.color="orange", .label="Chebyshev"});

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Равномерная параметризация
    plt.subplot(2, 2, 2);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(cubic1.xs(N), cubic1.ys(N), {.color="blue", .label="Uniform"});
    plt.plot(cubic1.xs(n), cubic1.ys(n), {.linestyle="none", .color="blue", .marker="."});

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Параметризация по длине хорд
    plt.subplot(2, 2, 3);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(cubic2.xs(N), cubic2.ys(N), {.color="green", .label="Chord Length"});
    plt.plot(cubic2.xs(n), cubic2.ys(n), {.linestyle="none", .color="green", .marker="."});
    plt.plot(xs, ys, node_style);
    plt.legend();

    // Параметризация по корням полинома Чебышёва
    plt.subplot(2, 2, 4);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(cubic3.xs(N), cubic3.ys(N), {.color="orange", .label="Chebyshev"});
    plt.plot(cubic3.xs(n), cubic3.ys(n), {.linestyle="none", .color="orange", .marker="."});
    plt.plot(xs, ys, node_style);
    plt.legend();

    plt.suptitle("Параметризация кубических сплайнов");
    plt.tight_layout();
    plt.show();
}

// Параметризация полиномов Лагранжа
void lagrange_parametrization() {
    // Узлы сплайна
    std::vector<double> xs = {0.0, 4.0, 10.0, 7.0, 8.0, 1.0};
    std::vector<double> ys = {1.0, 5.0, 6.0, 3.0, 0.0, 0.0};

    PLagrange poly1(xs, ys, SplineBound::Crop, SplineBound::Crop, Parametrization::Uniform);
    PLagrange poly2(xs, ys, SplineBound::Crop, SplineBound::Crop, Parametrization::Chord);
    PLagrange poly3(xs, ys, SplineBound::Crop, SplineBound::Crop, Parametrization::Chebyshev);

    // Число тестовых точек
    int n = 50;
    int N = 200;

    utils::pyplot plt;
    plt.figure({.figsize={9.0, 7}, .dpi=150});

    // Все виды параметризации
    plt.subplot(2, 2, 1);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(poly1.xs(N), poly1.ys(N), {.color="blue", .label="Uniform"});
    plt.plot(poly2.xs(N), poly2.ys(N), {.color="green", .label="Chord Length"});
    plt.plot(poly3.xs(N), poly3.ys(N), {.color="orange", .label="Chebyshev"});

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Равномерная параметризация
    plt.subplot(2, 2, 2);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(poly1.xs(N), poly1.ys(N), {.color="blue", .label="Uniform"});

    plt.plot(poly1.xs(n), poly1.ys(n), {.linestyle="none", .color="blue", .marker="."});

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Параметризация по длине хорд
    plt.subplot(2, 2, 3);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(poly2.xs(N), poly2.ys(N), {.color="green", .label="Chord Length"});
    plt.plot(poly2.xs(n), poly2.ys(n), {.linestyle="none", .color="green", .marker="."});

    plt.plot(xs, ys, node_style);
    plt.legend();

    // Параметризация по корням полинома Чебышёва
    plt.subplot(2, 2, 4);
    plt.grid(true);
    plt.set_aspect_equal();
    plt.xlim(-2.0, 11.0);
    plt.ylim(-2.0, 7.0);

    plt.plot(poly3.xs(N), poly3.ys(N), {.color="orange", .label="Chebyshev"});

    plt.plot(poly3.xs(n), poly3.ys(n), {.linestyle="none", .color="orange", .marker="."});

    plt.plot(xs, ys, node_style);
    plt.legend();

    plt.suptitle("Параметризация полиномов Лагранжа");
    plt.tight_layout();
    plt.show();
}

int main() {
    // Обычные интерполянты: y(x)
    ordinary_interpolants();

    // Параметрические интерполянты: x(t), y(t)
    parametric_interpolants();

    // Параметризация кубических сплайнов
    cubic_parametrization();

    // Параметризация полиномов Лагранжа
    lagrange_parametrization();

    return 0;
}