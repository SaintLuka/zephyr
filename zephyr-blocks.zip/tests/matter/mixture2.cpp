#include <iostream>
#include <iomanip>
#include <algorithm>

#include <zephyr/geom/vector.h>

#include <zephyr/phys/matter/eos/ideal_gas.h>
#include <zephyr/phys/matter/eos/stiffened_gas.h>
#include <zephyr/phys/matter/eos/mie_gruneisen.h>
#include <zephyr/phys/matter/mixture_pt.h>

#include <zephyr/utils/numpy.h>
#include <zephyr/utils/pyplot.h>

using namespace zephyr;
using namespace zephyr::geom;
using namespace zephyr::phys;

double fraction(double x) {
    double delta = 0.6;
    if (x > +delta) {
        return 0.0;
    } else if (x < -delta) {
        return 1.0;
    } else {
        double c = std::sin(0.25 * M_PI * (x + delta) / delta);
        return 1.0 - c * c;
    }
}

int main() {
    // Смесь
    auto eos1 = MieGruneisen::create("Pb");
    auto eos2 = IdealGas::create("Air");

    MixturePT mixture;
    mixture += eos1;
    mixture += eos2;

    auto x = np::linspace(-1.0, 1.0, 10000);
    //auto x = np::linspace(-0.65, -0.55, 1000);
    //auto x = np::linspace(-0.6, -0.595, 10000);

    auto a1 = np::empty_like(x);
    auto a2 = np::empty_like(x);
    for (size_t i = 0; i < x.size(); ++i) {
        a1[i] = fraction(x[i]);
        a2[i] = 1.0 - a1[i];
    }

    // Истинные значения
    double dens1 = 10100.0;
    double pres1 = -1.0e9;
    double vol1  = 1.0 / dens1;
    double enrg1 = eos1->energy_rP(dens1, pres1);
    double temp1 = eos1->temperature_rP(dens1, pres1);
    double dens2 = 5.0;
    double pres2 = 8.0e6;
    double vol2  = 1.0 / dens2;
    double enrg2 = eos2->energy_rP(dens2, pres2);
    double tempA = eos2->temperature_rP(dens2, pres2);

    auto mix_dens = np::empty_like(x);
    auto mix_engy = np::empty_like(x);
    auto mix_pres = np::empty_like(x);
    auto mix_temp = np::empty_like(x);
    auto beta1 = np::empty_like(x);
    auto beta2 = np::empty_like(x);

    auto mix_gamma = np::empty_like(x);
    auto mix_p_min = np::empty_like(x);
    auto mix_e0    = np::empty_like(x);

    for (size_t i = 0; i < x.size(); ++i) {
        mix_dens[i] = a1[i] * dens1 + a2[i] * dens2;

        beta1[i] = a1[i] * dens1 / mix_dens[i];
        beta2[i] = a2[i] * dens2 / mix_dens[i];

        mix_engy[i] = beta1[i] * enrg1 + beta2[i] * enrg2;

        Fractions beta = {beta1[i], beta2[i]};
        mix_pres[i] = mixture.pressure_re(mix_dens[i], mix_engy[i], beta);
        mix_temp[i] = mixture.temperature_rP(mix_dens[i], mix_pres[i], beta);

        StiffenedGas gas = mixture.stiffened_gas(mix_dens[i], mix_pres[i], beta);
        mix_gamma[i] = gas.gamma;
        mix_p_min[i] = gas.min_pressure();
        mix_e0[i] = gas.e0;
    }

    utils::pyplot plt;

    plt.figure({.figsize={15.0, 8.0}});

    plt.subplot2grid(2, 3, 0, 0);
    plt.title("Vol Fractions");
    //plt.plot(x, a1, "k-o");
    plt.plot(x, a2);

    plt.subplot2grid(2, 3, 1, 0);
    plt.title("Mass Fractions");
    //plt.plot(x, beta1);
    plt.plot(x, beta2);

    plt.subplot2grid(2, 3, 0, 1);
    plt.title("Mix density");
    plt.plot(x, mix_dens);

    plt.subplot2grid(2, 3, 0, 2);
    plt.title("Mix energy");
    plt.plot(x, mix_engy);

    plt.subplot2grid(2, 3, 1, 1);
    plt.title("Mix pressure");
    plt.plot(x, mix_pres);

    plt.subplot2grid(2, 3, 1, 2);
    plt.title("Mix temperature");
    plt.plot(x, mix_temp);

    plt.tight_layout();
    plt.show();

    return 0;
}