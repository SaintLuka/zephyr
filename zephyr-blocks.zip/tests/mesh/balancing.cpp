// Балансировка сетки на одном процессе. Демонстрирует работу алгоритмов
// балансировки нагрузки и подходит для их отладки.

#include <iostream>

#include <zephyr/io/pvd_file.h>

#include <zephyr/mesh/euler/eu_mesh.h>
#include <zephyr/mesh/decomp/ORB.h>
#include <zephyr/mesh/decomp/VD3.h>
#include <zephyr/mesh/decomp/rwalk.h>

#include <zephyr/geom/generator/cuboid.h>
#include <zephyr/geom/generator/rectangle.h>


using namespace zephyr::mesh;
using zephyr::utils::mpi;
using zephyr::io::PvdFile;
using zephyr::geom::Box;
using zephyr::geom::Vector3d;
using zephyr::geom::generator::Cuboid;
using zephyr::geom::generator::Rectangle;

using zephyr::mesh::decomp::ORB;
using zephyr::mesh::decomp::VD3;
using zephyr::mesh::decomp::RWalk;

// Для хранения на сетке
struct Data {
    Storable<int> rank;
    Storable<double> load;
};

// Абстрактная нагрузка
double foo(const Vector3d& v) {
    Vector3d c1 = {0.2, 0.4, 0.0};
    Vector3d c2 = {0.6, 0.1, 0.0};
    Vector3d c3 = {0.8, 0.4, 0.0};
    double A1 = 200.0;
    double A2 = 100.0;
    double A3 = 50.0;
    double s1 = 0.15;
    double s2 = 0.2;
    double s3 = 0.1;
    return A1/s1 * std::exp(-(v - c1).squaredNorm() / (s1 * s1)) +
           A2/s2 * std::exp(-(v - c2).squaredNorm() / (s2 * s2)) +
           A3/s3 * std::exp(-(v - c3).squaredNorm() / (s3 * s3));
}

// Посчитать фиктивную нагрузку
std::vector<double> calc_loads(EuMesh& mesh, int size, Data data) {
    std::vector<double> ws(size, 1.0e-3);
    for (auto cell: mesh) {
        if (cell[data.rank] < 0 || cell[data.rank] > size) {
            throw std::runtime_error("Wrong rank");
        }
        ws[cell[data.rank]] += cell[data.load];
    }
    return ws;
}

int main() {
    // Сеточный генератор
    //Cuboid gen(0.0, 1.0, 0.0, 0.6, 0.0, 0.9);
    Rectangle gen(0.0, 1.0, 0.0, 0.6);
    gen.set_nx(200);

    // Bounding Box для сетки
    Box domain = gen.bbox();

    // Создаем сетку
    EuMesh mesh(gen);

    // Добавить переменные на сетку
    Data data;
    data.rank = mesh.add<int>("rank");
    data.load = mesh.add<double>("load");

    // Файл для записи
    PvdFile pvd("mesh", "output");

    pvd.variables.append("rank", data.rank);
    pvd.variables.append("load", data.load);

    // Заполняем данные о нагрузке ячеек
    for (auto cell: mesh) {
        cell[data.load] = foo(cell.center());
    }

    // Различные варианты инициализации ORB декомпозиции
    //auto decmp = ORB::create(domain, "XY", -1, {2, 3, 4, 5, 1});
    //auto decmp = ORB::create(domain, "YX", 13);
    auto decmp = ORB::create(domain, "YX", 13, 3);
    //auto decmp = VD3::create(domain, 23);
    //auto decmp = RWalk::create(domain, 3);

    for (int step = 0; step < 1000; ++step) {
        // Вычисляем новый ранг ячеек
        for (auto &cell: mesh.locals()) {
            cell[data.rank] = decmp->rank(cell);
        }

        if (step % 10 == 0) {
            std::cout << "Step:      " << step << "; \t";
            pvd.save(mesh, step);
        }

        // Подсчитываем нагрузку каждого ранга
        auto ws = calc_loads(mesh, decmp->size(), data);

        if (step % 10 == 0) {
            std::cout << "Imbalance: " << decmp->imbalance(ws) << "\n";
        }

        // Балансировка декомпозиции
        decmp->balancing(ws);
    }

    return 0;
}